import React from "react";
import {Breadcrumbs, BreadcrumbItem} from "@nextui-org/react";

export default function App() {
  return (
    <Breadcrumbs className="ml-4">
      <BreadcrumbItem>Home</BreadcrumbItem>
      <BreadcrumbItem>Charts</BreadcrumbItem>
      <BreadcrumbItem>PieCharts</BreadcrumbItem>
      
    </Breadcrumbs>
  );
}
