'use client'
import { Margarine } from 'next/font/google';
import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const RADIAN = Math.PI / 180;

const cx = 150;
const cy = 200;
const iR = 50;
const oR = 100;

interface PieData {
  name: string;
  value: number;
  color: string;
}

const NeedlePieChart = () => {
  const [data, setData] = useState<PieData[]>([]);

  // Function to fetch data from Flask API endpoints
  const fetchData = async () => {
    try {
      const response1 = await fetch('http://localhost:5000/count_predictions');
      const data1 = await response1.json();

      const response2 = await fetch('http://localhost:5000/count_predictions_staying');
      const data2 = await response2.json();
      console.log("data",data1,data2)
      // Update state with fetched data
      setData([
        { name: 'Leaving', value: data1.count, color: '#8884d8' },
        { name: 'Staying', value: data2.count, color: '#82ca9d' },
      ]);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  // Use useEffect to fetch data periodically
  useEffect(() => {
    const fetchDataInterval = setInterval(() => {
      fetchData();
    }, 1500);

    // Clear the interval on component unmount to prevent memory leaks
    return () => clearInterval(fetchDataInterval);
  }, []); // Empty dependency array ensures this effect runs once on mount

  // Function to render the needle
  const renderNeedle = (value: number, total: number) => {
    const ang = 180.0 * (1 - value / total);
    const length = (iR + oR) / 2;
    const sin = Math.sin(-RADIAN * ang);
    const cos = Math.cos(-RADIAN * ang);
    const needleX = cx + length * cos;
    const needleY = cy + length * sin;

    return (
      <line
        x1={cx}
        y1={cy}
        x2={needleX}
        y2={needleY}
        stroke="#d0d000"
        strokeWidth="3"
        strokeLinecap="round"
      />
    );
  };

  return (
    <div style={{ width: '100%', height: 270, marginTop: '-20px' }}>
      <ResponsiveContainer  >
        <PieChart margin={{ left: 50 }} width={1000} >
          <Pie 
            dataKey="value"
            startAngle={180}
            endAngle={0}
            data={data}
            cx={cx}
            cy={cy}
            innerRadius={iR}
            outerRadius={oR}
            fill="#8884d8"
            stroke="none"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip />
          <Legend layout="vertical" verticalAlign="bottom" align="center" />
          {renderNeedle(data[0]?.value || 0, data.reduce((acc, cur) => acc + cur.value, 0))}
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default NeedlePieChart;
