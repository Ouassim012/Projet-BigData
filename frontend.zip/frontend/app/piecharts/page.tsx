'use client'
import React from 'react';
import PieChartComponent from './pie1';
import NeedlePieChart from '../piecharts/needlepiechart';
import Link from "next/link";
import { HouseIcon } from '@/components/icons/breadcrumb/house-icon';
import { UsersIcon } from '@/components/icons/breadcrumb/users-icon';
import App from "../piecharts/breadcrumbs"
const PieCharts = () => {
  return (
    
    <div className="h-full flex flex-col gap-2 mt-20" style={{ maxWidth: '950px' }}>
      <h3 className="text-xl font-semibold text-left ml-4" style={{marginTop:"-2px"}}>PieCharts</h3>
      <App/>
      <div className="flex gap-2 mt-10 ml-4">
        {/* First Chart - Pie Chart */}
        <div className="w-full bg-default-50 shadow-lg rounded-2xl p-6 flex-1">
          <h3 className="text-xl font-semibold text-center">Pie Chart</h3>
          <PieChartComponent />
        </div>

        {/* Second Chart - Needle Pie Chart */}
        <div className="w-full bg-default-50 shadow-lg rounded-2xl p-6 flex-1">
          <h3 className="text-xl font-semibold text-center">Needle Pie Chart</h3>
          <NeedlePieChart />
        </div>
      </div>
    </div>
  );
};

export default PieCharts;
