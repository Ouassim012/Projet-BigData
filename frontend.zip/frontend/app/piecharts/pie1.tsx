'use client'
import React, { useState, useEffect, useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const COLORS = ['#8884d8', '#82ca9d']; // Colors for the two sections of the pie chart
interface PieData {
    name: string;
    value: number;
  }
  

const SimplePieChart = () => {
  const [data, setData] = useState<PieData[]>([]);
  const memoizedTooltip = useMemo(() => <Tooltip />, []); // Memoize Tooltip component
  const memoizedLegend = useMemo(() => <Legend />, []); // Memoize Legend component
  // Function to fetch data from Flask API endpoints
  const fetchData = async () => {
    try {
      const response1 = await fetch('http://localhost:5000/count_predictions');
      const data1 = await response1.json();

      const response2 = await fetch('http://localhost:5000/count_predictions_staying');
      const data2 = await response2.json();
console.log("pie",data1,data2)
      // Update state with fetched data
      setData([
        { name: 'Leaving', value: data1.count },
        { name: 'Staying', value: data2.count },
      ]);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  // Use useEffect to fetch data on component mount
  useEffect(() => {
    const fetchDataInterval = setInterval(() => {
      fetchData();
    }, 1500);

    // Clear the interval on component unmount to prevent memory leaks
    return () => clearInterval(fetchDataInterval);
  }, []); // Empty dependency array ensures this effect runs once on mount

  return (
    <div style={{ width: '100%', height: 270 }}>
      <ResponsiveContainer>
        <PieChart>
          <Pie 
            data={data}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            outerRadius={80}
            fill="#82ca9d"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            labelLine={false}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index]} />
            ))}
          </Pie>
          {memoizedTooltip}
          <Legend layout="vertical" verticalAlign="bottom" align="center"  />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SimplePieChart;
