"use client";
import { Button, Input } from "@nextui-org/react";
import Link from "next/link";
import React, { useRef } from "react";
import { DotsIcon } from "@/components/icons/accounts/dots-icon";
import { ExportIcon } from "@/components/icons/accounts/export-icon";
import { InfoIcon } from "@/components/icons/accounts/info-icon";
import { TrashIcon } from "@/components/icons/accounts/trash-icon";
import { HouseIcon } from "@/components/icons/breadcrumb/house-icon";
import { UsersIcon } from "@/components/icons/breadcrumb/users-icon";
import { SettingsIcon } from "@/components/icons/sidebar/settings-icon";
import { TableWrapper } from "@/components/table/table";
import { AddUser } from "./add-user";
import TableComponent from "../table/tableau"
import handleExportToCSV from "../table/tableau"
export const Accounts = () => {
  const tableRef = useRef<HTMLButtonElement>(null);

  const handleExportCSV = () => {
    if (tableRef.current) {
      tableRef.current.click();
    }
  };
  return (
    <div className="my-14 lg:px-6 max-w-[95rem] mx-auto w-full flex flex-col gap-4">
      <ul className="flex">
        <li className="flex gap-2">
          <HouseIcon />
          <Link href={"/"}>
            <span>Home</span>
          </Link>
          <span> / </span>{" "}
        </li>

        <li className="flex gap-2">
          <UsersIcon />
          <span>Data-Streaming</span>
        </li>
      
      </ul>

      <h3 className="text-xl font-semibold">Data-Streaming</h3>
      <div className="flex justify-between flex-wrap gap-4 items-center">
        <div className="flex items-center gap-3 flex-wrap md:flex-nowrap">
          <Input
            classNames={{
              input: "w-full",
              mainWrapper: "w-full",
            }}
            placeholder="Search State"
          />
          
        </div>
      
      </div>
      <div className="max-w-[95rem] mx-auto w-fit">
        <TableComponent />
      </div>
    </div>
  );
};
