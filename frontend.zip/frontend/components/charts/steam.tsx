'use client'
import styles from './chart.module.css'
import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const Chart = () => {
  const [chartData, setChartData] = useState([]);

  // Function to fetch new data from Flask
  const fetchDataFromFlask = async () => {
    try {
      const response = await fetch('http://localhost:5000/');
      const data = await response.json();

      // Extract relevant data for the chart
      const { prediction, customer_service_calls } = data;

      // Prepare new data format for the chart
      const newData = {
        name: new Date().toLocaleTimeString(), // Use timestamp as X-axis label
        prediction: prediction,
        customerServiceCalls: customer_service_calls
      };

      // Update chartData with a maximum of 10 data points
      setChartData(prevData => {
        const updatedData = [...prevData, newData];
        if (updatedData.length > 10) {
          // Remove the oldest data point if the array length exceeds 10
          return updatedData.slice(updatedData.length - 10);
        } else {
          return updatedData;
        }
      });
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  // Use useEffect to initiate the data fetching interval
  useEffect(() => {
    const intervalId = setInterval(fetchDataFromFlask, 1500);

    // Clear interval on component unmount to avoid memory leaks
    return () => clearInterval(intervalId);
  }, []); // Run this effect only once on component mount

  return (
    <div style={{ width: '100%' }}>
      <ResponsiveContainer   height={200}>
        <AreaChart
          width={500}
          height={200}
          data={chartData}
          syncId="anyId"
          margin={{
            top: 10,
            right: 30,
            left: -20,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Area type="monotone" dataKey="prediction" stroke="#8884d8" fill="#8884d8" />
          <Area type="monotone" dataKey="customerServiceCalls" stroke="#82ca9d" fill="#82ca9d" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default Chart;
