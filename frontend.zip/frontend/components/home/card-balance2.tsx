import { Card, CardBody } from "@nextui-org/react";
import React, { useEffect, useState } from "react";
import { Community } from "../icons/community";

export const CardBalance2 = () => {
    const [totalPersons, setTotalPersons] = useState(0);
 // Function to fetch total number of persons from MongoDB
 const fetchTotalPersons = async () => {
  try {
    // Perform your fetch operation here
    const response = await fetch("http://localhost:5000/count_predictions"); // Replace with your API endpoint
    const data = await response.json();

    // Assuming 'total' is the key in the response containing the total number of persons
    const { count } = data;
    console.log("data coming out of the big shaow",data)
    const {percentage_change}=data

    // Update the state with the fetched total value
    setTotalPersons(count);
  } catch (error) {
    console.error("Error fetching total number of persons:", error);
  }
};

// Use useEffect to initiate the data fetching interval
useEffect(() => {
  const intervalId = setInterval(fetchTotalPersons, 2000); // Fetch data every 2 seconds

  // Clean up the interval on component unmount
  return () => clearInterval(intervalId);
}, []); // Run this effect only once on component mount

  return (
    <Card className="xl:max-w-sm bg-default-50 rounded-xl shadow-md px-3 w-60 h-fit">
    <CardBody className="py-5 overflow-hidden">
      <div className="flex gap-2.5 ">
        <Community />
        <div className="flex flex-col">
          <span className="text-default-900">Nombre Totale</span>
          <span className="text-default-900 text-xs">des Personnes Quitter  </span>
        </div>
      </div>
      <div className="flex gap-2.5 py-2 items-center ">
        <span className="text-default-900 text-xl font-semibold ml-10">{totalPersons}</span>
        <span className="text-success text-xs">Leaving</span>
      </div>
     
    </CardBody>
  </Card>
  );
};
