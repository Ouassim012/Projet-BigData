import React from "react";

interface Props {
  color?: string;
}

export const Community = ({ color = "white" }: Props) => {
  return (
    <svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 20a5 5 0 0 0 0-10V4a7 7 0 0 1 0 14 7 7 0 0 1 0-14V2a10 10 0 1 0 0 20z" />
</svg>

  );
};
