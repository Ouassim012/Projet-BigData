import React from "react";

export const StatisticsIcon = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3 18V20H5V18H3ZM3 14V16H5V14H3ZM3 6V12H5V6H3ZM7 20V22H9V20H7ZM7 16V18H9V16H7ZM7 12V14H9V12H7ZM11 20V24H13V20H11ZM11 14V18H13V14H11ZM11 6V10H13V6H11ZM15 20V22H17V20H15ZM15 16V18H17V16H15ZM15 12V14H17V12H15ZM19 20V24H21V20H19ZM19 14V18H21V14H19ZM19 6V10H21V6H19Z"
        fill="#969696"
        className="fill-default-400"

      />
    </svg>
  );
};
