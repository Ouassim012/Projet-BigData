'use client'
import Chart from "../charts/steam"
import React from 'react'
export default function PieCharts(){
    return(<div className="h-full flex flex-col gap-2">
    <h3 className="text-xl font-semibold">Analyse des donnees</h3>
    <div className="w-full bg-default-50 shadow-lg rounded-2xl p-6 ">
      <Chart />
    </div>
    </div>)
}


