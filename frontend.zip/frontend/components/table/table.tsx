// TableWrapper Component
import React, { useState, useEffect } from "react";
import {
  Table,
  TableHeader,
  TableColumn,
  TableBody,
  TableRow,
  TableCell,
} from "@nextui-org/react";
import RenderCell from "./render-cell";

const API_URL = "http://localhost:5000/"; // Update with your API endpoint

export const TableWrapper: React.FC = () => {
  const [tableData, setTableData] = useState<any>({}); // Initialize as an empty object

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(API_URL);
        if (response.ok) {
          const jsonData = await response.json();
          console.log("Fetched Data:", jsonData); // Log fetched data
          setTableData(jsonData); // Set fetched data to state
        } else {
          throw new Error("Failed to fetch data");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData(); // Fetch data on component mount
  }, []); // Empty dependency array ensures effect runs only once on mount

  console.log("Table Data:", tableData); // Log tableData for debugging

  return (
    <div className="w-full flex flex-col gap-4">
      <Table aria-label="Example table with custom cells">
        <TableHeader>
          <TableColumn>State</TableColumn>
          <TableColumn>Account Length</TableColumn>
          <TableColumn>Customer Service Calls</TableColumn>
          <TableColumn>Voice Mail Plan</TableColumn>
          <TableColumn>Total Day Charge</TableColumn>
        </TableHeader>
        <TableBody>
          <TableRow>
            <RenderCell value={tableData["State"]} columnKey="State" />
            <RenderCell value={tableData["Account length"]} columnKey="Account length" />
            <RenderCell value={tableData["Customer service calls"]} columnKey="Customer service calls" />
            <RenderCell value={tableData["Voice mail plan"]} columnKey="Voice mail plan" />
            <RenderCell value={tableData["Total day charge"]} columnKey="Total day charge" />
          </TableRow>
        </TableBody>
      </Table>
    </div>
  );
};

export default TableWrapper;
