import React, { useEffect, useState } from "react";
import {
  Table,
  TableHeader,
  TableColumn,
  TableBody,
  TableRow,
  TableCell,
  Chip,
  Pagination,
} from "@nextui-org/react";

interface DataItem {
  state: string;
  account_length: number;
  international_plan: string;
  Voice_mail_plan: string;
  number_vmail_messages: number;
  prediction: number;
  "Total day calls": number;
  total_day_charge: number;
  total_eve_minutes: number;
  "Total eve calls": number;
  total_eve_charge: number;
  "Total night minutes": number;
  "Total night calls": number;
  total_night_charge: number;
  "Total intl minutes": number;
  "Total intl calls": number;
  "Total intl charge": number;
  customer_service_calls: number;
}

const renderPrediction = (prediction: number) => {
  if (prediction === 1) {
    return <Chip className="capitalize" size="sm" variant="flat" color="danger">Leaving</Chip>;
  } else if (prediction === 0) {
    return <Chip className="capitalize" color="success" size="sm" variant="flat">Staying</Chip>;
  }
  return null; // Handle other cases if needed
};

const TableComponent: React.FC = () => {
  const [data, setData] = useState<DataItem[]>([]);
  const [page, setPage] = useState(1);
  const rowsPerPage = 5;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:5000/");
        if (response.ok) {
          const jsonData = await response.json();
          setData((prevData) => [...prevData, jsonData]); // Append new data to existing data
        } else {
          throw new Error("Failed to fetch data");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    const intervalId = setInterval(fetchData, 2500); // Fetch data every 3.5 seconds
    return () => clearInterval(intervalId); // Clean up interval

  }, []);
  
  const handleExportToCSV = () => {
    const csvContent =
    "data:text/csv;charset=utf-8," +
    Object.keys(data[0]).join(",") +
    "\n" +
    data.map((item) => Object.values(item).join(",")).join("\n");

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "data.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  };

  const totalItems = data.length;
  const totalPages = Math.ceil(totalItems / rowsPerPage);
  const startIdx = (page - 1) * rowsPerPage;
  const endIdx = startIdx + rowsPerPage;
  const currentItems = data.slice(startIdx, endIdx);

  const handlePageChange = (pageNumber: number) => {
    setPage(pageNumber);
  };

  return (
    <div className="w-full">
      <Table aria-label="Data Table"
      
      bottomContent={
        <div className="flex w-full justify-center">
          <Pagination
            isCompact
            showControls
            showShadow
            color="secondary"
            page={page}
            total={totalPages}
            onChange={(page) => setPage(page)}
          />
        </div>
      }
      classNames={{
        wrapper: "min-h-[222px]",
      }}
      >
        <TableHeader>
          <TableColumn>Voice Mail Plan</TableColumn>
          <TableColumn>Customer Service Calls</TableColumn>
          <TableColumn>International Plan</TableColumn>
          <TableColumn>Number Vmail Messages</TableColumn>
          <TableColumn>Total Eve Charge</TableColumn>
          <TableColumn>Total Eve Minutes</TableColumn>
          <TableColumn>Churn</TableColumn>
        </TableHeader>
        <TableBody>
          {currentItems.map((item, index) => (
            <TableRow key={index}>
              <TableCell style={{ textAlign: 'center' }}>{item.Voice_mail_plan}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>{item.customer_service_calls}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>{item.international_plan}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>{item.number_vmail_messages}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>${item.total_eve_charge.toFixed(1)}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>{item.total_eve_minutes.toFixed(1)}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>{renderPrediction(item.prediction)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <button id="exportButton" onClick={handleExportToCSV} style={{ display: "none" }} />

    
    </div>
  );
};

export default TableComponent;
